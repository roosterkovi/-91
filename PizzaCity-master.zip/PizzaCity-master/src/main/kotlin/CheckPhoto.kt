interface CheckPhoto {
    var checkCount: Int
    var checkDiscount: Double
    fun showCheckPhoto()
}