interface Sauce {
    var sauceOneSaleCount: Int
    var sauceOneSalePrice: Double
    var sauceTwoSaleCount: Int
    var sauceTwoSalePrice: Double
    fun sauceSale()
}