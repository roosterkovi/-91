interface Drink {
    var drinkSaleCount: Int
    var drinkSalePrice: Double
    fun drinkSale()
}